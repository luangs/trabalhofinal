package aulaso20161.trabalhofinal.dao.webservice;


import android.content.Context;

import com.android.volley.Request;
import aulaso20161.trabalhofinal.dao.custom.CustomPostResquest;
import aulaso20161.trabalhofinal.dao.custom.CustomResquest;
import aulaso20161.trabalhofinal.dao.local.LocalDbImplement;
import aulaso20161.trabalhofinal.dao.voley.CallListener;
import aulaso20161.trabalhofinal.dao.voley.GerenicAbstractDaoImp;
import aulaso20161.trabalhofinal.model.BaseModel;
import aulaso20161.trabalhofinal.model.UserModel;
import aulaso20161.trabalhofinal.model.Usuario;
import aulaso20161.trabalhofinal.model.request.BaseRequest;
import aulaso20161.trabalhofinal.model.request.ItenRequest;
import aulaso20161.trabalhofinal.model.request.LenteRequest;
import aulaso20161.trabalhofinal.model.request.UsuarioRequest;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.HashMap;



/**
 * Created by luan on 05/04/2016
 */
public class BaseDao extends GerenicAbstractDaoImp {

    public BaseDao(Context context) {
        super(context);
    }


    public void getFocos(CallListener callListener) {
        String url = serverUrl + "getters/getFocos.php";
        CustomResquest request = new CustomResquest(ItenRequest.class, Request.Method.GET, url, null, callListener, callListener);
        addRequest(request);
    }

    public void getVisao(CallListener callListener, ArrayList<BaseModel> dependencia) {
        String url = serverUrl + "getters/getVisao.php";
        HashMap<String, String> map = new HashMap<>();

        map.put("dependencia", new Gson().toJson(dependencia));

        CustomResquest request = new CustomResquest(ItenRequest.class, Request.Method.POST, url, map, callListener, callListener);
        addRequest(request);
    }


    public void getPFabricacao(CallListener callListener,ArrayList<BaseModel> dependencia) {
        String url = serverUrl + "getters/getPFabricacao.php";

        HashMap<String, String> map = new HashMap<>();

        map.put("dependencia", new Gson().toJson(dependencia));

        CustomResquest request = new CustomResquest(ItenRequest.class, Request.Method.POST, url, map, callListener, callListener);
        addRequest(request);
    }

    public void getDFabricacao(CallListener callListener,ArrayList<BaseModel> dependencia) {
        String url = serverUrl + "getters/getDFabricacao.php";
        HashMap<String, String> map = new HashMap<>();

        map.put("dependencia", new Gson().toJson(dependencia));

        CustomResquest request = new CustomResquest(ItenRequest.class, Request.Method.POST, url, map, callListener, callListener);
        addRequest(request);
    }


    public void getParametros(CallListener callListener) {
        String url = serverUrl + "getters/getParametros.php";
        CustomResquest request = new CustomResquest(ItenRequest.class, Request.Method.GET, url, null, callListener, callListener);
        addRequest(request);
    }

    public void getFabricantes(CallListener callListener) {
        String url = serverUrl + "getters/getFabricantes.php";
        CustomResquest request = new CustomResquest(ItenRequest.class, Request.Method.GET, url, null, callListener, callListener);
        addRequest(request);
    }

    public void getMaterial1(CallListener callListener) {
        String url = serverUrl + "getters/getMaterial1.php";
        CustomResquest request = new CustomResquest(ItenRequest.class, Request.Method.GET, url, null, callListener, callListener);
        addRequest(request);
    }

    public void getMaterial2(CallListener callListener) {
        String url = serverUrl + "getters/getMaterial2.php";
        CustomResquest request = new CustomResquest(ItenRequest.class, Request.Method.GET, url, null, callListener, callListener);
        addRequest(request);
    }

    public void getCores(CallListener callListener) {
        String url = serverUrl + "getters/getCores.php";
        CustomResquest request = new CustomResquest(ItenRequest.class, Request.Method.GET, url, null, callListener, callListener);
        addRequest(request);
    }

    public void getTratamentos(CallListener callListener) {
        String url = serverUrl + "getters/getTratamentos.php";
        CustomResquest request = new CustomResquest(ItenRequest.class, Request.Method.GET, url, null, callListener, callListener);
        addRequest(request);
    }

    public void getRefracao(CallListener callListener) {
        String url = serverUrl + "getters/getRefracao.php";
        CustomResquest request = new CustomResquest(ItenRequest.class, Request.Method.GET, url, null, callListener, callListener);
        addRequest(request);
    }


    public void filter(CallListener callListener, ArrayList<BaseModel> foco, ArrayList<BaseModel> visao, ArrayList<BaseModel> pfabricacao, ArrayList<BaseModel> dfabricacao, ArrayList<BaseModel> parametros, ArrayList<BaseModel> fabricantes, ArrayList<BaseModel> material, ArrayList<BaseModel> material2, ArrayList<BaseModel> cores, ArrayList<BaseModel> tratamento, ArrayList<BaseModel> refracao) {
        HashMap<String, String> map = new HashMap<>();
        map.put("foco", new Gson().toJson(foco));

        if (visao.size() > 0)
            map.put("visao", new Gson().toJson(visao));
        if (pfabricacao.size() > 0)
            map.put("pfabricacao", new Gson().toJson(pfabricacao));
        if (dfabricacao.size() > 0)
            map.put("dfabricacao", new Gson().toJson(dfabricacao));
        if (parametros.size() > 0)
            map.put("parametros", new Gson().toJson(parametros));
        if (fabricantes.size() > 0)
            map.put("fabricantes", new Gson().toJson(fabricantes));
        if (material.size() > 0)
            map.put("material1", new Gson().toJson(material));
        if (material2.size() > 0)
            map.put("material2", new Gson().toJson(material2));
        if (cores.size() > 0)
            map.put("cores", new Gson().toJson(cores));
        if (tratamento.size() > 0)
            map.put("tratamento", new Gson().toJson(tratamento));
        if (refracao.size() > 0)
            map.put("refracao", new Gson().toJson(refracao));


        String url = serverUrl + "setters/filtros.php";

        CustomPostResquest request = new CustomPostResquest(LenteRequest.class, Request.Method.POST, url, map, callListener, callListener);
        addRequest(request);
    }



    public void filtroreferencia(CallListener callListener) {
        String url = serverUrl + "getters/getFiltroReferencia.php";

        CustomPostResquest request = new CustomPostResquest(ItenRequest.class, Request.Method.GET, url, null, callListener, callListener);
        addRequest(request);
    }


    public void filtrodireto(CallListener callListener, String filtro) {
        HashMap<String, String> map = new HashMap<>();
        map.put("filtro",filtro);

        String url = serverUrl + "getters/getFiltroDireto.php";

        CustomPostResquest request = new CustomPostResquest(LenteRequest.class, Request.Method.POST, url, map, callListener, callListener);
        addRequest(request);
    }


    public void getAtualizacao(CallListener callListener, String data) {

        HashMap<String, String> map = new HashMap<>();
        map.put("data",data);

        String url = serverUrl + "getters/getAtualizacao.php";

        CustomPostResquest request = new CustomPostResquest(ItenRequest.class, Request.Method.POST, url, map, callListener, callListener);
        addRequest(request);
    }

    public void addUserProduto(CallListener callListener, String idProduto) {
        Usuario user = new LocalDbImplement<Usuario>(context).getDefault(Usuario.class);

        String url = serverUrl + "setters/addUserProduto.php?idProduto=" + idProduto+"&idUser="+user.getId();

        CustomResquest request = new CustomResquest(BaseRequest.class, Request.Method.GET, url, null, callListener, callListener);
        addRequest(request);
    }

    public void favoritar(CallListener callListener, UserModel userModel, String option){
        HashMap<String, String> map = new HashMap<>();
        map.put("idProduto",String.valueOf(userModel.getId()));
        map.put("nome",userModel.getNome());

        String url = serverUrl + "setters/addFavorito.php?tipo="+option;

        CustomPostResquest request = new CustomPostResquest(ItenRequest.class, Request.Method.POST, url, map, callListener, callListener);
        addRequest(request);
    }

    public void login(CallListener callListener, String pass, String email){
        HashMap<String, String> map = new HashMap<>();
        map.put("pass",pass);
        map.put("email",email);

        String url = serverUrl + "safe/loginmobile.php";

        CustomPostResquest request = new CustomPostResquest(UsuarioRequest.class, Request.Method.POST, url, map, callListener, callListener);
        addRequest(request);
    }

    public void addUser(CallListener callListener,String nome,  String email,String pass,String empresa,String estado,String cidade){
        HashMap<String, String> map = new HashMap<>();
        map.put("Nome",nome);
        map.put("Email",email);
        map.put("Senha",pass);
        map.put("Empresa",empresa);
        map.put("Estado",estado);
        map.put("Cidade",cidade);

        String url = serverUrl + "setters/addUser.php";

        CustomPostResquest request = new CustomPostResquest(BaseRequest.class, Request.Method.POST, url, map, callListener, callListener);
        addRequest(request);
    }

    public void recupera(CallListener callListener,String email){
        HashMap<String, String> map = new HashMap<>();
        map.put("email",email);

        String url = serverUrl + "setters/addRecuperarSenha.php";

        CustomPostResquest request = new CustomPostResquest(BaseRequest.class, Request.Method.POST, url, map, callListener, callListener);
        addRequest(request);
    }
}
