package aulaso20161.trabalhofinal.model.request;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

import aulaso20161.trabalhofinal.model.LenteModel;

/**
 * Created by Dev_Maker on 11/04/2016.
 */
public class LenteRequest extends BaseRequest{

    @Expose
    @SerializedName("content")
    public List<LenteModel> itens;

    public List<LenteModel> getItens() {
        return itens;
    }

    public void setItens(List<LenteModel> itens) {
        this.itens = itens;
    }

}
