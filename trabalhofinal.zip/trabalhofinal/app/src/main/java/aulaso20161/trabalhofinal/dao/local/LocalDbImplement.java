package aulaso20161.trabalhofinal.dao.local;

import android.content.Context;

/**
 * Created by renato on 02/02/2015.
 */
public class LocalDbImplement<E> extends AbstractLocalDb<E> {


    public LocalDbImplement(Context context) {
        super(context);
    }
}
