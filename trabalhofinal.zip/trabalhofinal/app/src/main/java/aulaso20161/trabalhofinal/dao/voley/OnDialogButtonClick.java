package aulaso20161.trabalhofinal.dao.voley;


public interface OnDialogButtonClick {
	public void onPositiveClick();
	public void onNegativeClick();
}
