package aulaso20161.trabalhofinal.dao.voley;

/**
 * Created by Renato on 14/01/2015.
 */
public interface VolleyOnPreExecute {
    public void onPreExecute();
}
