package aulaso20161.trabalhofinal.model;

import java.io.Serializable;

/**
 * Created by Dev_Maker on 14/04/2016.
 */
public class PurchaseItem implements Serializable {
    private String Id;
    private String Sku;
    private String Title;
    private String Type;
    private String Price;
    private String Description;
    private String Status;


    public String getId() {
        return Id;
    }

    public void setId(String id) {
        Id = id;
    }

    public String getSku() {
        return Sku;
    }

    public void setSku(String sku) {
        Sku = sku;
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String title) {
        Title = title;
    }

    public String getType() {
        return Type;
    }

    public void setType(String type) {
        Type = type;
    }

    public String getPrice() {
        return Price;
    }

    public void setPrice(String price) {
        Price = price;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        Description = description;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String status) {
        Status = status;
    }
}
