package aulaso20161.trabalhofinal.dao.voley;

/**
 * Created by anderson on 05/11/2015.
 */
public abstract class DataResponse {
    public abstract boolean success();
}
