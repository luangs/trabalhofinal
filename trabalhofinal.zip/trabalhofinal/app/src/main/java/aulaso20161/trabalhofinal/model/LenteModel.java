 package aulaso20161.trabalhofinal.model;

 import com.google.gson.annotations.Expose;
 import com.google.gson.annotations.SerializedName;

 import java.io.Serializable;

 ;

 public class LenteModel implements Serializable{

    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("Codigo")
    @Expose
    private String Codigo;
    @SerializedName("CodigoFoco")
    @Expose
    private Object CodigoFoco;
    @SerializedName("LogoFoco")
    @Expose
    private Object LogoFoco;
    @SerializedName("SiglaFoco")
    @Expose
    private String SiglaFoco;
    @SerializedName("NomeFoco")
    @Expose
    private String NomeFoco;
    @SerializedName("NomeLente")
    @Expose
    private String NomeLente;
    @SerializedName("CodigoVisao")
    @Expose
    private Object CodigoVisao;
    @SerializedName("SiglaVisao")
    @Expose
    private String SiglaVisao;
    @SerializedName("NomeVisao")
    @Expose
    private String NomeVisao;
    @SerializedName("id_grupo")
    @Expose
    private String idGrupo;
    @SerializedName("CodigoFabricacao")
    @Expose
    private Object CodigoFabricacao;
    @SerializedName("SiglaPFabricacao")
    @Expose
    private String SiglaPFabricacao;
    @SerializedName("ProFabricacao")
    @Expose
    private String ProFabricacao;
    @SerializedName("id_tamanho")
    @Expose
    private String idTamanho;
    @SerializedName("CodigoDetmento")
    @Expose
    private Object CodigoDetmento;
    @SerializedName("SiglaDFabricacao")
    @Expose
    private String SiglaDFabricacao;
    @SerializedName("DetFabricacao")
    @Expose
    private String DetFabricacao;
    @SerializedName("CodigoParametros")
    @Expose
    private Object CodigoParametros;
    @SerializedName("SiglaParametros")
    @Expose
    private String SiglaParametros;
    @SerializedName("NomeParametros")
    @Expose
    private String NomeParametros;
    @SerializedName("ID_Material")
    @Expose
    private String IDMaterial;
    @SerializedName("CodigoMaterial")
    @Expose
    private Object CodigoMaterial;
    @SerializedName("MaterialNome1")
    @Expose
    private String MaterialNome1;
    @SerializedName("CodigoMatFab")
    @Expose
    private Object CodigoMatFab;
    @SerializedName("MaterialFab")
    @Expose
    private String MaterialFab;
    @SerializedName("ID_Marca")
    @Expose
    private String IDMarca;
    @SerializedName("CodigoMarca")
    @Expose
    private Object CodigoMarca;
    @SerializedName("SiglaMarca")
    @Expose
    private String SiglaMarca;
    @SerializedName("NomeMarca")
    @Expose
    private String NomeMarca;
    @SerializedName("ID_Tratamento")
    @Expose
    private String IDTratamento;
    @SerializedName("CodigoTratmento")
    @Expose
    private Object CodigoTratmento;
    @SerializedName("LogoTratamento")
    @Expose
    private Object LogoTratamento;
    @SerializedName("TratamentoNome")
    @Expose
    private String TratamentoNome;
    @SerializedName("CodigoReferencia")
    @Expose
    private Object CodigoReferencia;
    @SerializedName("ReferenciaComp")
    @Expose
    private String ReferenciaComp;
    @SerializedName("ValorCusto")
    @Expose
    private String ValorCusto;
    @SerializedName("ValorVenda")
    @Expose
    private String ValorVenda;
    @SerializedName("id_Cores")
    @Expose
    private String idCores;
    @SerializedName("CodigoCores")
    @Expose
    private Object CodigoCores;
    @SerializedName("LogoCores")
    @Expose
    private Object LogoCores;
    @SerializedName("Tratamento")
    @Expose
    private String Tratamento;
    @SerializedName("ID_Fabricante")
    @Expose
    private String IDFabricante;
    @SerializedName("CodigoFabricante")
    @Expose
    private Object CodigoFabricante;
    @SerializedName("LogoFabricante")
    @Expose
    private Object LogoFabricante;
    @SerializedName("FabricanteNome")
    @Expose
    private String FabricanteNome;
    @SerializedName("id_Refracao")
    @Expose
    private String idRefracao;
    @SerializedName("CodigoRefracao")
    @Expose
    private Object CodigoRefracao;
    @SerializedName("Refracao")
    @Expose
    private String Refracao;

    private String descricaoHtml;

    private boolean favorited;

    public LenteModel() {

    }

    public String getDescricaoHtml(String hasPurchase) {
        if(descricaoHtml == null && hasPurchase.equalsIgnoreCase("COMPRADO"))
            this.descricaoHtml = "<strong>"+this.getFabricanteNome()+" <font color=#3b64af> > </font></strong> "+this.getProFabricacao()+"  <strong><font color=#3b64af> > </font></strong> " + this.getNomeLente() + "  <strong><font color=#3b64af> > </font></strong> " + this.getReferenciaComp() + "  <strong><font color=#3b64af> > </font></strong> " + this.getMaterialFab() + "  <strong><font color=#3b64af> > </font></strong> " + this.getTratamento() + "  <strong><font color=#3b64af> > </font></strong> " + this.getTratamentoNome() + "  <strong><font color=#3b64af> > </font></strong>  "+ this.getRefracao() +" <strong><font color=#3b64af> > </font></strong> <strong>R$" + this.getValorVenda() + "</strong>";
        if(descricaoHtml == null && hasPurchase.equalsIgnoreCase("NaO COMPRADO"))
            this.descricaoHtml = "<strong>"+this.getFabricanteNome()+" <font color=#3b64af> > </font></strong> "+this.getProFabricacao()+"  <strong><font color=#3b64af> > </font></strong> " + this.getNomeLente() + "  <strong><font color=#3b64af> > </font></strong> " + this.getReferenciaComp() + "  <strong><font color=#3b64af> > </font></strong> " + this.getMaterialFab() + "  <strong><font color=#3b64af> > </font></strong> " + this.getTratamento() + "  <strong><font color=#3b64af> > </font></strong> " + this.getTratamentoNome() + "  <strong><font color=#3b64af> > </font></strong>  "+ this.getRefracao();


       return descricaoHtml;
    }


    public boolean isFavorited() {
       return favorited;
    }

    public void setFavorited(boolean favorited) {
       this.favorited = favorited;
    }

    /**
     *
     * @return
     * The id
     */
    public String getId() {
        return id;
    }

    /**
     *
     * @param id
     * The id
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     *
     * @return
     * The Codigo
     */
    public String getCodigo() {
        return Codigo;
    }

    /**
     *
     * @param Codigo
     * The Codigo
     */
    public void setCodigo(String Codigo) {
        this.Codigo = Codigo;
    }

    /**
     *
     * @return
     * The CodigoFoco
     */
    public Object getCodigoFoco() {
        return CodigoFoco;
    }

    /**
     *
     * @param CodigoFoco
     * The CodigoFoco
     */
    public void setCodigoFoco(Object CodigoFoco) {
        this.CodigoFoco = CodigoFoco;
    }

    /**
     *
     * @return
     * The LogoFoco
     */
    public Object getLogoFoco() {
        return LogoFoco;
    }

    /**
     *
     * @param LogoFoco
     * The LogoFoco
     */
    public void setLogoFoco(Object LogoFoco) {
        this.LogoFoco = LogoFoco;
    }

    /**
     *
     * @return
     * The SiglaFoco
     */
    public String getSiglaFoco() {
        return SiglaFoco;
    }

    /**
     *
     * @param SiglaFoco
     * The SiglaFoco
     */
    public void setSiglaFoco(String SiglaFoco) {
        this.SiglaFoco = SiglaFoco;
    }

    /**
     *
     * @return
     * The NomeFoco
     */
    public String getNomeFoco() {
        return NomeFoco;
    }

    /**
     *
     * @param NomeFoco
     * The NomeFoco
     */
    public void setNomeFoco(String NomeFoco) {
        this.NomeFoco = NomeFoco;
    }

    /**
     *
     * @return
     * The NomeLente
     */
    public String getNomeLente() {
        return NomeLente;
    }

    /**
     *
     * @param NomeLente
     * The NomeLente
     */
    public void setNomeLente(String NomeLente) {
        this.NomeLente = NomeLente;
    }

    /**
     *
     * @return
     * The CodigoVisao
     */
    public Object getCodigoVisao() {
        return CodigoVisao;
    }

    /**
     *
     * @param CodigoVisao
     * The CodigoVisao
     */
    public void setCodigoVisao(Object CodigoVisao) {
        this.CodigoVisao = CodigoVisao;
    }

    /**
     *
     * @return
     * The SiglaVisao
     */
    public String getSiglaVisao() {
        return SiglaVisao;
    }

    /**
     *
     * @param SiglaVisao
     * The SiglaVisao
     */
    public void setSiglaVisao(String SiglaVisao) {
        this.SiglaVisao = SiglaVisao;
    }

    /**
     *
     * @return
     * The NomeVisao
     */
    public String getNomeVisao() {
        return NomeVisao;
    }

    /**
     *
     * @param NomeVisao
     * The NomeVisao
     */
    public void setNomeVisao(String NomeVisao) {
        this.NomeVisao = NomeVisao;
    }

    /**
     *
     * @return
     * The idGrupo
     */
    public String getIdGrupo() {
        return idGrupo;
    }

    /**
     *
     * @param idGrupo
     * The id_grupo
     */
    public void setIdGrupo(String idGrupo) {
        this.idGrupo = idGrupo;
    }

    /**
     *
     * @return
     * The CodigoFabricacao
     */
    public Object getCodigoFabricacao() {
        return CodigoFabricacao;
    }

    /**
     *
     * @param CodigoFabricacao
     * The CodigoFabricacao
     */
    public void setCodigoFabricacao(Object CodigoFabricacao) {
        this.CodigoFabricacao = CodigoFabricacao;
    }

    /**
     *
     * @return
     * The SiglaPFabricacao
     */
    public String getSiglaPFabricacao() {
        return SiglaPFabricacao;
    }

    /**
     *
     * @param SiglaPFabricacao
     * The SiglaPFabricacao
     */
    public void setSiglaPFabricacao(String SiglaPFabricacao) {
        this.SiglaPFabricacao = SiglaPFabricacao;
    }

    /**
     *
     * @return
     * The ProFabricacao
     */
    public String getProFabricacao() {
        if(ProFabricacao != null)
            return ProFabricacao;
        else
            return "Não informado";
    }

    /**
     *
     * @param ProFabricacao
     * The ProFabricacao
     */
    public void setProFabricacao(String ProFabricacao) {
       if(ProFabricacao != null)
         this.ProFabricacao = ProFabricacao;
       else
          this.ProFabricacao = "Não informado";
    }

    /**
     *
     * @return
     * The idTamanho
     */
    public String getIdTamanho() {
        return idTamanho;
    }

    /**
     *
     * @param idTamanho
     * The id_tamanho
     */
    public void setIdTamanho(String idTamanho) {
        this.idTamanho = idTamanho;
    }

    /**
     *
     * @return
     * The CodigoDetmento
     */
    public Object getCodigoDetmento() {
        return CodigoDetmento;
    }

    /**
     *
     * @param CodigoDetmento
     * The CodigoDetmento
     */
    public void setCodigoDetmento(Object CodigoDetmento) {
        this.CodigoDetmento = CodigoDetmento;
    }

    /**
     *
     * @return
     * The SiglaDFabricacao
     */
    public String getSiglaDFabricacao() {
        return SiglaDFabricacao;
    }

    /**
     *
     * @param SiglaDFabricacao
     * The SiglaDFabricacao
     */
    public void setSiglaDFabricacao(String SiglaDFabricacao) {
        this.SiglaDFabricacao = SiglaDFabricacao;
    }

    /**
     *
     * @return
     * The DetFabricacao
     */
    public String getDetFabricacao() {
        return DetFabricacao;
    }

    /**
     *
     * @param DetFabricacao
     * The DetFabricacao
     */
    public void setDetFabricacao(String DetFabricacao) {
        this.DetFabricacao = DetFabricacao;
    }

    /**
     *
     * @return
     * The CodigoParametros
     */
    public Object getCodigoParametros() {
        return CodigoParametros;
    }

    /**
     *
     * @param CodigoParametros
     * The CodigoParametros
     */
    public void setCodigoParametros(Object CodigoParametros) {
        this.CodigoParametros = CodigoParametros;
    }

    /**
     *
     * @return
     * The SiglaParametros
     */
    public String getSiglaParametros() {
        return SiglaParametros;
    }

    /**
     *
     * @param SiglaParametros
     * The SiglaParametros
     */
    public void setSiglaParametros(String SiglaParametros) {
        this.SiglaParametros = SiglaParametros;
    }

    /**
     *
     * @return
     * The NomeParametros
     */
    public String getNomeParametros() {
        return NomeParametros;
    }

    /**
     *
     * @param NomeParametros
     * The NomeParametros
     */
    public void setNomeParametros(String NomeParametros) {
        this.NomeParametros = NomeParametros;
    }

    /**
     *
     * @return
     * The IDMaterial
     */
    public String getIDMaterial() {
        return IDMaterial;
    }

    /**
     *
     * @param IDMaterial
     * The ID_Material
     */
    public void setIDMaterial(String IDMaterial) {
        this.IDMaterial = IDMaterial;
    }

    /**
     *
     * @return
     * The CodigoMaterial
     */
    public Object getCodigoMaterial() {
        return CodigoMaterial;
    }

    /**
     *
     * @param CodigoMaterial
     * The CodigoMaterial
     */
    public void setCodigoMaterial(Object CodigoMaterial) {
        this.CodigoMaterial = CodigoMaterial;
    }

    /**
     *
     * @return
     * The MaterialNome1
     */
    public String getMaterialNome1() {
        return MaterialNome1;
    }

    /**
     *
     * @param MaterialNome1
     * The MaterialNome1
     */
    public void setMaterialNome1(String MaterialNome1) {
        this.MaterialNome1 = MaterialNome1;
    }

    /**
     *
     * @return
     * The CodigoMatFab
     */
    public Object getCodigoMatFab() {
        return CodigoMatFab;
    }

    /**
     *
     * @param CodigoMatFab
     * The CodigoMatFab
     */
    public void setCodigoMatFab(Object CodigoMatFab) {
        this.CodigoMatFab = CodigoMatFab;
    }

    /**
     *
     * @return
     * The MaterialFab
     */
    public String getMaterialFab() {
        return MaterialFab;
    }

    /**
     *
     * @param MaterialFab
     * The MaterialFab
     */
    public void setMaterialFab(String MaterialFab) {
        this.MaterialFab = MaterialFab;
    }

    /**
     *
     * @return
     * The IDMarca
     */
    public String getIDMarca() {
        return IDMarca;
    }

    /**
     *
     * @param IDMarca
     * The ID_Marca
     */
    public void setIDMarca(String IDMarca) {
        this.IDMarca = IDMarca;
    }

    /**
     *
     * @return
     * The CodigoMarca
     */
    public Object getCodigoMarca() {
        return CodigoMarca;
    }

    /**
     *
     * @param CodigoMarca
     * The CodigoMarca
     */
    public void setCodigoMarca(Object CodigoMarca) {
        this.CodigoMarca = CodigoMarca;
    }

    /**
     *
     * @return
     * The SiglaMarca
     */
    public String getSiglaMarca() {
        return SiglaMarca;
    }

    /**
     *
     * @param SiglaMarca
     * The SiglaMarca
     */
    public void setSiglaMarca(String SiglaMarca) {
        this.SiglaMarca = SiglaMarca;
    }

    /**
     *
     * @return
     * The NomeMarca
     */
    public String getNomeMarca() {
        return NomeMarca;
    }

    /**
     *
     * @param NomeMarca
     * The NomeMarca
     */
    public void setNomeMarca(String NomeMarca) {
        this.NomeMarca = NomeMarca;
    }

    /**
     *
     * @return
     * The IDTratamento
     */
    public String getIDTratamento() {
        return IDTratamento;
    }

    /**
     *
     * @param IDTratamento
     * The ID_Tratamento
     */
    public void setIDTratamento(String IDTratamento) {
        this.IDTratamento = IDTratamento;
    }

    /**
     *
     * @return
     * The CodigoTratmento
     */
    public Object getCodigoTratmento() {
        return CodigoTratmento;
    }

    /**
     *
     * @param CodigoTratmento
     * The CodigoTratmento
     */
    public void setCodigoTratmento(Object CodigoTratmento) {
        this.CodigoTratmento = CodigoTratmento;
    }

    /**
     *
     * @return
     * The LogoTratamento
     */
    public Object getLogoTratamento() {
        return LogoTratamento;
    }

    /**
     *
     * @param LogoTratamento
     * The LogoTratamento
     */
    public void setLogoTratamento(Object LogoTratamento) {
        this.LogoTratamento = LogoTratamento;
    }

    /**
     *
     * @return
     * The TratamentoNome
     */
    public String getTratamentoNome() {
        return TratamentoNome;
    }

    /**
     *
     * @param TratamentoNome
     * The TratamentoNome
     */
    public void setTratamentoNome(String TratamentoNome) {
        this.TratamentoNome = TratamentoNome;
    }

    /**
     *
     * @return
     * The CodigoReferencia
     */
    public Object getCodigoReferencia() {
        return CodigoReferencia;
    }

    /**
     *
     * @param CodigoReferencia
     * The CodigoReferencia
     */
    public void setCodigoReferencia(Object CodigoReferencia) {
        this.CodigoReferencia = CodigoReferencia;
    }

    /**
     *
     * @return
     * The ReferenciaComp
     */
    public String getReferenciaComp() {
        return ReferenciaComp;
    }

    /**
     *
     * @param ReferenciaComp
     * The ReferenciaComp
     */
    public void setReferenciaComp(String ReferenciaComp) {
        this.ReferenciaComp = ReferenciaComp;
    }

    /**
     *
     * @return
     * The ValorCusto
     */
    public String getValorCusto() {
        return ValorCusto;
    }

    /**
     *
     * @param ValorCusto
     * The ValorCusto
     */
    public void setValorCusto(String ValorCusto) {
        this.ValorCusto = ValorCusto;
    }

    /**
     *
     * @return
     * The ValorVenda
     */
    public String getValorVenda() {
        return ValorVenda;
    }

    /**
     *
     * @param ValorVenda
     * The ValorVenda
     */
    public void setValorVenda(String ValorVenda) {
        this.ValorVenda = ValorVenda;
    }

    /**
     *
     * @return
     * The idCores
     */
    public String getIdCores() {
        return idCores;
    }

    /**
     *
     * @param idCores
     * The id_Cores
     */
    public void setIdCores(String idCores) {
        this.idCores = idCores;
    }

    /**
     *
     * @return
     * The CodigoCores
     */
    public Object getCodigoCores() {
        return CodigoCores;
    }

    /**
     *
     * @param CodigoCores
     * The CodigoCores
     */
    public void setCodigoCores(Object CodigoCores) {
        this.CodigoCores = CodigoCores;
    }

    /**
     *
     * @return
     * The LogoCores
     */
    public Object getLogoCores() {
        return LogoCores;
    }

    /**
     *
     * @param LogoCores
     * The LogoCores
     */
    public void setLogoCores(Object LogoCores) {
        this.LogoCores = LogoCores;
    }

    /**
     *
     * @return
     * The Tratamento
     */
    public String getTratamento() {
        return Tratamento;
    }

    /**
     *
     * @param Tratamento
     * The Tratamento
     */
    public void setTratamento(String Tratamento) {
        this.Tratamento = Tratamento;
    }

    /**
     *
     * @return
     * The IDFabricante
     */
    public String getIDFabricante() {
        return IDFabricante;
    }

    /**
     *
     * @param IDFabricante
     * The ID_Fabricante
     */
    public void setIDFabricante(String IDFabricante) {
        this.IDFabricante = IDFabricante;
    }

    /**
     *
     * @return
     * The CodigoFabricante
     */
    public Object getCodigoFabricante() {
        return CodigoFabricante;
    }

    /**
     *
     * @param CodigoFabricante
     * The CodigoFabricante
     */
    public void setCodigoFabricante(Object CodigoFabricante) {
        this.CodigoFabricante = CodigoFabricante;
    }

    /**
     *
     * @return
     * The LogoFabricante
     */
    public Object getLogoFabricante() {
        return LogoFabricante;
    }

    /**
     *
     * @param LogoFabricante
     * The LogoFabricante
     */
    public void setLogoFabricante(Object LogoFabricante) {
        this.LogoFabricante = LogoFabricante;
    }

    /**
     *
     * @return
     * The FabricanteNome
     */
    public String getFabricanteNome() {
        return FabricanteNome;
    }

    /**
     *
     * @param FabricanteNome
     * The FabricanteNome
     */
    public void setFabricanteNome(String FabricanteNome) {
        this.FabricanteNome = FabricanteNome;
    }

    /**
     *
     * @return
     * The idRefracao
     */
    public String getIdRefracao() {
        return idRefracao;
    }

    /**
     *
     * @param idRefracao
     * The id_Refracao
     */
    public void setIdRefracao(String idRefracao) {
        this.idRefracao = idRefracao;
    }

    /**
     *
     * @return
     * The CodigoRefracao
     */
    public Object getCodigoRefracao() {
        return CodigoRefracao;
    }

    /**
     *
     * @param CodigoRefracao
     * The CodigoRefracao
     */
    public void setCodigoRefracao(Object CodigoRefracao) {
        this.CodigoRefracao = CodigoRefracao;
    }

    /**
     *
     * @return
     * The Refracao
     */
    public String getRefracao() {
        return Refracao;
    }

    /**
     *
     * @param Refracao
     * The Refracao
     */
    public void setRefracao(String Refracao) {
        this.Refracao = Refracao;
    }



}