package aulaso20161.trabalhofinal.model;

/**
 * Created by DevMaker on 5/27/16.
 */
public class Estado {
    private String nome;
    private String sigla;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getSigla() {
        return sigla;
    }

    public void setSigla(String sigla) {
        this.sigla = sigla;
    }

    public Estado(String nome) {
        this.nome = nome;
    }

    @Override
    public String toString() {
        return nome;
    }
}
